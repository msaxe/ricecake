# -*- coding: utf-8 -*-

__author__ = 'Mark Saxer'
__email__ = 'masaxer@cox.net'
__version__ = '0.1'